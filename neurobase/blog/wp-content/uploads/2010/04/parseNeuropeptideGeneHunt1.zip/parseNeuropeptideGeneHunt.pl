use warnings;
use strict;
use Bio::SeqIO;
use Bio::SearchIO;

my $usage = "parseNeuropeptideGeneHunt.pl <query fasta file> <homolog fasta file> <blast output file> - this script makes an excel sheet for you with all of the goodies that leonid wants\n";

my $query = shift or die $usage;
my $fasta = shift or die $usage;
my $blast = shift or die $usage;

#hash to hold all of the results by species
my %creatureHash = ();
#hash to hold all of the sequences that the students found
my %sequenceHash = ();
#hash to hold all of the query sequences
my %queryHash = ();

my $queryio = new Bio::SeqIO(-format=>"fasta", -file=>"$query");
while(my $seq = $queryio->next_seq){
  my $id = $seq->display_id . " " . $seq->desc;
  $id =~ s/(^\s+)|(\s+$)//g;
  $queryHash{$id} = $seq->seq;
}
#seqio object to iterate over the sequences
my $seqio = new Bio::SeqIO(-format=>"fasta", -file=>"$fasta");
while(my $seq = $seqio->next_seq){
  my $id = $seq->display_id . " " . $seq->desc;
  $id =~ s/(^\s+)|(\s+$)//g;
  my @ids = split(/gb\|/, $id);
  $id = $ids[1];
  my @ids2 = split(/\|/, $id);
  $id = $ids2[0];
  #my @split = split(/\|/, $id);
  #$id = $split[2] . "|" . $split[3] . "|";
  $sequenceHash{$id} = $seq->seq;
}
#the sequence hash is full, parse their BLAST outputs
my $searchio = new Bio::SearchIO(-file=>"$blast", -fomat=>"blast");
open(OUTFILE, ">$blast\_for_excel.txt");
print OUTFILE "SequenceID\tOrganism/Database\tHIt Identifier\tHit Accession #\tHit Sequence\tEvalue\t% Identity\t# Cystines - Hit Seq\t# Dibasic Sites - Hit Seq\t# Cystines - Query Seq\t#Dibasic Sites - Query Seq\n";
while(my $result = $searchio->next_result){
  my $queryID = $result->query_name . " " . $result->query_description;
  $queryID =~ s/(^\s+)|(\s+$)//g;
  print OUTFILE $queryID . "\n";
  my $querySeq = $queryHash{$queryID};
  my $qdibasics = 0;
  my $qcystines = 0;
  while($querySeq =~ /(KR)|(KK)|(RK)|(RR)/){
    $querySeq =~ s/(KR)|(KK)|(RK)|(RR)//;
    $qdibasics++;
  }
  while($querySeq =~ /C/){
    $querySeq =~ s/C//;
    $qcystines++;
  }
  while(my $hit = $result->next_hit){
    my $id = $hit->name . " " . $hit->description;
    $id =~ s/(^\s+)|(\s+$)//g;
    my @ids = split(/gb\|/, $id);
    my @ids2 = split(/\|/, $ids[1]);
    $id = $ids2[0];
    $creatureHash{$id}{seq} = $sequenceHash{$id};
    my $fullID = $hit->name . " " . $hit->description;
    $creatureHash{$id}{fullname} = $fullID;
    my $organism = "";
    if($fullID =~ /jgi/){
      $organism = "JGI";
    }
    else{
      my @split = split(/\]/,$fullID);
      my @splitAgain = split(/\[/, $split[0]);
      $organism = $splitAgain[1];
    }
    $creatureHash{$id}{organism} = $organism;
    $creatureHash{$id}{evalue} = $hit->significance;
    my $hsp = $hit->next_hsp;
    $creatureHash{$id}{identity} = $hsp->frac_identical * 100 . "%";
    #determine the number of dibasic sites
    my $dibasics = 0;
    my $cystines = 0;
    my $tmp = $creatureHash{$id}{seq};
    while($tmp =~ /(KR)|(KK)|(RK)|(RR)/){
      $tmp =~ s/(KR)|(KK)|(RK)|(RR)//;
      $dibasics++;
    }
    while($tmp =~ /C/){
      $tmp =~ s/C//;
      $cystines++;
    }
    if($creatureHash{$id}{organism} eq "more info"){
      $creatureHash{$id}{organism} = "JGI";
    }
    print OUTFILE "\t" . $creatureHash{$id}{organism} . "\t" . $creatureHash{$id}{fullname} . "\t" . $hit->accession . "\t" . $creatureHash{$id}{seq} . "\t" . $creatureHash{$id}{evalue} . "\t" . $creatureHash{$id}{identity} . "\t"  . $cystines . "\t" . $dibasics . "\t$qcystines" . "\t$qdibasics" . "\n";

  }

}

